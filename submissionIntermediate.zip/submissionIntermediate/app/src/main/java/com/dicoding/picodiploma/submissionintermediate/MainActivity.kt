package com.dicoding.picodiploma.submissionintermediate

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.activity.viewModels
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.picodiploma.submissionintermediate.adapter.LoadingAdapter
import com.dicoding.picodiploma.submissionintermediate.adapter.StoriesAdapter
import com.dicoding.picodiploma.submissionintermediate.databinding.ActivityMainBinding
import com.dicoding.picodiploma.submissionintermediate.model.LoginSession
import com.dicoding.picodiploma.submissionintermediate.viewmodel.MainViewModel
import com.dicoding.picodiploma.submissionintermediate.viewmodel.ViewModelFactory

class MainActivity : AppCompatActivity() {

    private val factory: ViewModelFactory = ViewModelFactory.getInstance(this)
    private val mMainViewMmodel: MainViewModel by viewModels{ factory }
    private lateinit var mSessionPreference: SessionPreference
    private lateinit var binding: ActivityMainBinding

    private var token: String? = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val loginSession = intent.getParcelableExtra<LoginSession>(EXTRA_RESULT) as LoginSession
        token = loginSession.token

        supportActionBar?.title = "Story"
        binding.list.layoutManager = LinearLayoutManager(this)

        getStories(loginSession)

        binding.newStory.setOnClickListener{
            val move = Intent(this@MainActivity, AddStoryActivity::class.java)
            move.putExtra(AddStoryActivity.LOGIN_SESSION, loginSession)
            startActivity(move)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.option_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean{
        itemResponse(item.itemId)
        return super.onOptionsItemSelected(item)
    }

    private fun itemResponse(selectedItem: Int){
        when (selectedItem){
            R.id.logout -> {
                logOut()
            }
            R.id.maps_mode -> {
                moveToMaps()
            }
        }
    }

    private fun logOut(){
        mSessionPreference = SessionPreference(this)
        mSessionPreference.deleteSession()
        Log.d(".MainActivity", "lihat : ${mSessionPreference.getSession()}")
        val moveToLogin = Intent(this@MainActivity, LoginActivity::class.java)
        startActivity(moveToLogin)
        finish()
    }

    private fun moveToMaps() {
        val intent = Intent(this@MainActivity, MapsActivity::class.java)
        mSessionPreference = SessionPreference(this)
        intent.putExtra(MapsActivity.TOKEN, mSessionPreference.getSession())
        startActivity(intent)
    }

    private fun getStories(loginSession: LoginSession) {
        showLoading(true)
        val storiesAdapter = StoriesAdapter()
        binding.list.adapter = storiesAdapter.withLoadStateFooter(
            footer = LoadingAdapter{
                storiesAdapter.retry()
            }
        )
        mMainViewMmodel.getStories(loginSession).observe(this, {
            Log.d(".HomeActivity", "data story : $it")
            storiesAdapter.submitData(lifecycle, it)
        })
        showLoading(false)
    }

    private fun getToken(): String?{
        return token
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.loadingBar.visibility = View.VISIBLE
        }else{
            binding.loadingBar.visibility = View.GONE
        }
    }

    companion object{
        const val EXTRA_RESULT = "extra_person"
    }
}