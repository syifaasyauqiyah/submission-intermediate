package com.dicoding.picodiploma.submissionintermediate.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.dicoding.picodiploma.submissionintermediate.api.ListStory
import com.dicoding.picodiploma.submissionintermediate.model.LoginSession
import com.dicoding.picodiploma.submissionintermediate.repoPaging.StoryRepo

class MapsViewModel(private val storyRepo: StoryRepo): ViewModel() {
    fun getMapsListStory(loginSession: LoginSession): LiveData<List<ListStory>>{
        storyRepo.setMapsListStory(loginSession)
        return storyRepo.getMapsListStory()
    }


}