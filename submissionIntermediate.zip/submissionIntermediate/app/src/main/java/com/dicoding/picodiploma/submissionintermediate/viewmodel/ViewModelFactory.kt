package com.dicoding.picodiploma.submissionintermediate.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.dicoding.picodiploma.submissionintermediate.injection.Injection
import com.dicoding.picodiploma.submissionintermediate.repoPaging.StoryRepo

class ViewModelFactory private constructor(private val storyRepo: StoryRepo): ViewModelProvider.Factory {
    override fun <T:ViewModel> create (modelClass: Class<T>): T{
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MainViewModel(storyRepo) as T
        }else if(modelClass.isAssignableFrom(MapsViewModel::class.java)){
            @Suppress("UNCHECKED_CAST")
            return MapsViewModel(storyRepo) as T
        }else if(modelClass.isAssignableFrom(AuthorizationViewModel::class.java)){
            @Suppress("UNCHECKED_CAST")
            return AuthorizationViewModel(storyRepo) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }

    companion object{
        @Volatile
        private var instance: ViewModelFactory? = null
        fun getInstance(context: Context): ViewModelFactory =
            instance ?: synchronized(this) {
                instance ?: ViewModelFactory(Injection.provideRepo(context))
            }.also { instance = it }
    }
}