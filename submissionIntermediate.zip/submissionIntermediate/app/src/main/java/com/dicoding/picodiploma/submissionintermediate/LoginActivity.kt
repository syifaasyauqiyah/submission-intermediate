package com.dicoding.picodiploma.submissionintermediate

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.dicoding.picodiploma.submissionintermediate.ValidatorHelper.cekEmail
import com.dicoding.picodiploma.submissionintermediate.databinding.ActivityLoginBinding
import com.dicoding.picodiploma.submissionintermediate.model.LoginSession
import com.dicoding.picodiploma.submissionintermediate.viewmodel.AuthorizationViewModel
import com.dicoding.picodiploma.submissionintermediate.viewmodel.ViewModelFactory

class LoginActivity : AppCompatActivity(){
    private lateinit var binding: ActivityLoginBinding
    private val factory: ViewModelFactory = ViewModelFactory.getInstance(this)
    private val authViewModel : AuthorizationViewModel by viewModels{ factory }
    private lateinit var loginSession: LoginSession
    private lateinit var mSessionPreference: SessionPreference

    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        playAnimation()
        mSessionPreference = SessionPreference(this)
        showLoading(false)

        supportActionBar?.title = "Login"

        setUpLanguage()

        if(mSessionPreference.getSession().name != ""){
            val newLoginSession = mSessionPreference.getSession()
            val intent = Intent(this@LoginActivity, MainActivity::class.java)
            intent.putExtra(MainActivity.EXTRA_RESULT, newLoginSession)
            startActivity(intent)
            finish()
        }

        setListener()

        binding.loginButton.setOnClickListener{
            if (validasi()) {
                showLoading(true)
                val email = binding.emailEditText.text.toString().trim()
                val password = binding.passwordEditText.text.toString().trim()
                authViewModel.loginLauncher(email, password).observe(this, {
                    if (it != null){
                        if (it.error == true){
                            showLoading(false)
                            Toast.makeText(this, "${it.message}", Toast.LENGTH_SHORT).show()
                        } else {
                            saveSession(it.loginResult.name,it.loginResult.token,it.loginResult.userId)
                        }
                    } else {
                        showLoading(false)
                        Toast.makeText(this, "Email atau Password anda salah", Toast.LENGTH_SHORT).show()
                    }
                })
            }
        }
        binding.registerIntent.setOnClickListener{
            val intent = Intent(this@LoginActivity, RegisterActivity::class.java)
            startActivity(intent)
        }
    }
    private fun setUpLanguage(){
        binding.setLanguage.setOnClickListener{
            startActivity(Intent(Settings.ACTION_LOCALE_SETTINGS))
        }
    }

    private fun playAnimation(){
        val email = ObjectAnimator.ofFloat(binding.email, View.ALPHA, 1f).setDuration(500)
        val emailEditText = ObjectAnimator.ofFloat(binding.emailEditText, View.ALPHA, 1f).setDuration(500)
        val password = ObjectAnimator.ofFloat(binding.password, View.ALPHA, 1f).setDuration(500)
        val passwordEditText = ObjectAnimator.ofFloat(binding.passwordEditText, View.ALPHA, 1f).setDuration(500)
        val loginButton = ObjectAnimator.ofFloat(binding.loginButton, View.ALPHA, 1f).setDuration(500)
        val register = ObjectAnimator.ofFloat(binding.registerIntent, View.ALPHA, 1f).setDuration(500)

        AnimatorSet().apply{
            playTogether(email, emailEditText)
            startDelay = 500
        }.start()

        AnimatorSet().apply{
            playTogether(password, passwordEditText)
            startDelay = 500
        }.start()

        AnimatorSet().apply{
            playSequentially(
                loginButton,
                register
            )
            startDelay = 500
        }.start()
        ObjectAnimator.ofFloat(binding.registerIntent, View.TRANSLATION_X, -30f, 30f).apply{
            duration = 6000
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
        }.start()
    }

    private fun saveSession(name: String, token: String, userId: String) {
        mSessionPreference = SessionPreference(this)

        loginSession = LoginSession()
        loginSession.name = name
        loginSession.token = token
        loginSession.userId = userId

        mSessionPreference.setSession(loginSession)
        moveToHome()
    }

    private fun moveToHome() {
        mSessionPreference = SessionPreference(this)
        val newLoginSession= mSessionPreference.getSession()
        val intent = Intent(this@LoginActivity, MainActivity::class.java)
        Toast.makeText(this, "validated", Toast.LENGTH_SHORT).show()
        intent.putExtra(MainActivity.EXTRA_RESULT, newLoginSession)
        startActivity(intent)
        finish()
    }

    private fun validasi(): Boolean = validEmail() && validPassword()

    private fun setListener() {
        with(binding) {
            emailEditText.addTextChangedListener(validasiInput(emailEditText))
            passwordEditText.addTextChangedListener(validasiInput(passwordEditText))
        }
    }

    private fun validEmail(): Boolean {
        if (binding.emailEditText.text.toString().trim().isEmpty()) {
            binding.emailEditText.error =  "Belum terisi"
            binding.emailEditText.requestFocus()
            return false
        }else if(!cekEmail(binding.emailEditText.text.toString())){
            binding.emailEditText.error =  "Email tidak valid"
            binding.emailEditText.requestFocus()
            return false
        }else{
            return true
        }

    }

    private fun validPassword(): Boolean {
        if (binding.passwordEditText.text.toString().trim().isEmpty()) {
            binding.passwordEditText.error = "Tidak Boleh Kosong"
            binding.passwordEditText.requestFocus()
            return false
        }else if (binding.passwordEditText.text.toString().length < 6) {
            binding.passwordEditText.error = "password kurang dari 6"
            binding.passwordEditText.requestFocus()
            return false
        }else{
            return true
        }
    }

    inner class validasiInput(private val view: View): TextWatcher {
        override fun afterTextChanged(s: Editable?) {}
        override fun beforeTextChanged(s: CharSequence?, p1: Int, p2: Int, p3: Int) {}
        override fun onTextChanged(s: CharSequence?, p1: Int, p2: Int, p3: Int) {
            when (view.id) {
                R.id.email_edit_text -> {
                    validEmail()
                }
                R.id.password_edit_text -> {
                    validPassword()
                }
            }
        }
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.loadingBar.visibility = View.VISIBLE
        }else{
            binding.loadingBar.visibility = View.GONE
        }
    }
}