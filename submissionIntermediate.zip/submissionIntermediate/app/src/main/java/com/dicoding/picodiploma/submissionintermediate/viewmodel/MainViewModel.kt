package com.dicoding.picodiploma.submissionintermediate.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.paging.PagingData
import com.dicoding.picodiploma.submissionintermediate.api.ApiConfig
import com.dicoding.picodiploma.submissionintermediate.api.ListStory
import com.dicoding.picodiploma.submissionintermediate.api.StoryResponse
import com.dicoding.picodiploma.submissionintermediate.model.LoginSession
import com.dicoding.picodiploma.submissionintermediate.repoPaging.StoryRepo
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainViewModel(private val storyRepo: StoryRepo): ViewModel() {

    fun getStories(loginSession: LoginSession): LiveData<PagingData<ListStory>> {
        Log.d("lihat data", "${loginSession.token}\n${storyRepo.getUser(loginSession)}")
        return storyRepo.getUser(loginSession)
    }
}