package com.dicoding.picodiploma.submissionintermediate.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.dicoding.picodiploma.submissionintermediate.api.ApiConfig
import com.dicoding.picodiploma.submissionintermediate.api.LoginResponse
import com.dicoding.picodiploma.submissionintermediate.api.LoginResult
import com.dicoding.picodiploma.submissionintermediate.api.RegisterResponse
import com.dicoding.picodiploma.submissionintermediate.repoPaging.StoryRepo
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AuthorizationViewModel(private val storyRepo: StoryRepo): ViewModel(){

    fun registerLauncher(name:String, email: String, password: String): LiveData<RegisterResponse?> {
        storyRepo.registerLauncherRepo(name, email, password)
        return storyRepo.getRegisterResponse()
    }

    fun loginLauncher(email: String, password: String): LiveData<LoginResponse?>{
        storyRepo.loginLauncherRepo(email, password)
        return storyRepo.getLoginResponse()
    }
}