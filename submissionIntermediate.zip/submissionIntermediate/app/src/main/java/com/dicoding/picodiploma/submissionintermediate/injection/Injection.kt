package com.dicoding.picodiploma.submissionintermediate.injection

import android.content.Context
import com.dicoding.picodiploma.submissionintermediate.api.ApiConfig
import com.dicoding.picodiploma.submissionintermediate.repoPaging.StoryRepo

object Injection {
    fun provideRepo(context : Context): StoryRepo{
        val apiService = ApiConfig.getApiService()
        return StoryRepo.getInstance(apiService)
    }
}