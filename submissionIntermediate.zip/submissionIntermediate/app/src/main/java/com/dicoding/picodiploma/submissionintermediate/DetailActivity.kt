package com.dicoding.picodiploma.submissionintermediate

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.dicoding.picodiploma.submissionintermediate.api.ListStory
import com.dicoding.picodiploma.submissionintermediate.databinding.ActivityDetailBinding

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        showLoading(true)

        supportActionBar?.title = "Detail Story"
        val story = intent.getParcelableExtra<ListStory>(OBJECT) as ListStory
        Log.d("DetailStory","$story")

        with(binding) {
            name.text = story.name
            description.text = story.description
            Glide.with(this@DetailActivity)
                .load(story.photoUrl)
                .into(storyPicture)
        }
        showLoading(false)
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.loadingBar.visibility = View.VISIBLE
        }else{
            binding.loadingBar.visibility = View.GONE
        }
    }

    companion object {
        const val OBJECT = "object"
    }
}