package com.dicoding.picodiploma.submissionintermediate

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.dicoding.picodiploma.submissionintermediate.databinding.ActivityMapsBinding
import com.dicoding.picodiploma.submissionintermediate.viewmodel.MainViewModel
import com.dicoding.picodiploma.submissionintermediate.viewmodel.MapsViewModel
import com.dicoding.picodiploma.submissionintermediate.viewmodel.ViewModelFactory
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationResult
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.android.gms.maps.model.MarkerOptions

class MapsActivity: AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding
    private lateinit var mSession: SessionPreference
    private val factory: ViewModelFactory = ViewModelFactory.getInstance(this)
    private val mMapsViewModel : MapsViewModel by viewModels{ factory }
    private var storyLoc: ArrayList<LatLng>? = null
    private var storyName: ArrayList<String>? = null
    private var storyDesc: ArrayList<String>? = null
    private lateinit var locationCallback: LocationCallback


    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mSession = SessionPreference(this)
        mMap = googleMap

        mMap.uiSettings.isZoomControlsEnabled = true
        mMap.uiSettings.isIndoorLevelPickerEnabled = true
        mMap.uiSettings.isCompassEnabled = true
        mMap.uiSettings.isMapToolbarEnabled = true

        mMapsViewModel.getMapsListStory(mSession.getSession()).observe(this, {
            var latlngarray = ArrayList<LatLng>()
            for (listStory in it) {
                val latLng = LatLng(listStory.lat, listStory.lon)
                latlngarray.add(latLng)
                mMap.addMarker(
                    MarkerOptions().position(latLng)
                        .position(latLng)
                        .title("Posisi ${listStory.name}")
                        .snippet("${listStory.description}")
                )
                mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng))
            }
        })
        getMyLocation()
        createLocationCallback()
        setUpMarker()
    }

    private val requestPermissionLauncher =
        registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { isGranted: Boolean ->
            if (isGranted) {
                getMyLocation()
            }
        }

    private fun getMyLocation(){
        if(ContextCompat.checkSelfPermission(
                this.applicationContext,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            mMap.isMyLocationEnabled = true
        } else {
            requestPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    private fun createLocationCallback(){
        locationCallback = object : LocationCallback(){
            override fun onLocationResult(locationResult: LocationResult) {
                for (location in locationResult.locations) {
                    Log.d(TAG, "onLocationResult: " + location.latitude + ", " + location.longitude)
                }
            }
        }
    }

    private fun setUpMarker(){
        storyLoc = intent.getParcelableArrayListExtra(EXTRA_LOC)
        storyName = intent.getStringArrayListExtra(EXTRA_NAME)
        storyDesc = intent.getStringArrayListExtra(EXTRA_DESC)

        Log.d("Cek data: ", "$storyLoc & $storyName & $storyDesc")

        if (storyLoc != null){
            for (i in storyLoc?.indices!!){
                mMap.addMarker(
                    MarkerOptions()
                        .position(storyLoc!![i])
                        .title(storyName!![i])
                        .snippet(storyDesc!![i])
                )
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(storyLoc!![i], 20f))
            }
        }
    }

    companion object{
        const val TOKEN = "token"
        const val EXTRA_LOC = "extra_loc"
        const val EXTRA_NAME = "extra_name"
        const val EXTRA_DESC = "extra_desc"
        const val TAG = "Maps_Acitivity"
    }
}